# web-provider

Provider para gerenciamento e compartilhamento de estado em aplicações Angular.

## Instalação

```bash
npm install web-provider
```

Peer dependencies:

```bash
npm install @angular/core rxjs
```

Se o seu provider usar `HttpClient`, configure isso na sua aplicação Angular normalmente:

```bash
npm install @angular/common
```

## Configuração

No `app.config.ts`:

```typescript
import { ApplicationConfig } from '@angular/core';
import { provideWebProviderInitializer } from 'web-provider';

export const appConfig: ApplicationConfig = {
  providers: [
    provideWebProviderInitializer({
      storage: 'localStorage',
      keyPrefix: 'my_app',
      syncStorage: true,
    }),
  ],
};
```

Opções globais:

| Opção | Valor | Padrão |
|------|-------|--------|
| `storage` | `'localStorage'`, `'sessionStorage'` ou `'memory'` | `'localStorage'` |
| `keyPrefix` | Prefixo das chaves persistidas | `'web-provider'` |
| `syncStorage` | Carrega cache imediatamente | `false` |
| `ttl` | Tempo de vida do provider em ms | sem expiração |
| `clearStorageOnExpire` | Remove cache quando expira | `false` |

## Provider com RxJS

```typescript
import { webProvider, WebNotifierProvider, WebRef } from 'web-provider';

interface UserState {
  name: string;
  logged: boolean;
}

class UserProvider extends WebNotifierProvider<UserState> {
  constructor() {
    super({ name: '', logged: false });
  }

  login(name: string) {
    this.setState({ name, logged: true });
  }

  logout() {
    this.setState({ name: '', logged: false });
  }
}

export const userProvider = webProvider(
  'user',
  (_ref: WebRef) => new UserProvider()
);
```

Uso em componente:

```typescript
const user = userProvider.snapshot;
const name$ = userProvider.select((state) => state.name);

userProvider.login('Belmiro');
```

## Provider com Angular Signals

```typescript
import { webProvider, WebNotifierSignalProvider } from 'web-provider';

interface CounterState {
  count: number;
}

class CounterProvider extends WebNotifierSignalProvider<CounterState> {
  constructor() {
    super({ count: 0 });
  }

  increment() {
    this.setState((state) => ({ count: state.count + 1 }));
  }
}

export const counterProvider = webProvider(
  'counter',
  () => new CounterProvider()
);
```

Uso:

```typescript
const count = counterProvider.select((state) => state.count);
counterProvider.increment();
```

## Injetando serviços da sua app

A lib não fornece `HttpClient`. Injete o serviço que a sua aplicação já configurou:

```typescript
import { HttpClient } from '@angular/common/http';
import { webProvider, WebRef } from 'web-provider';

class ApiProvider {
  constructor(private http: HttpClient) {}

  getUsers() {
    return this.http.get('/api/users');
  }
}

export const apiProvider = webProvider('api', (ref: WebRef) => {
  const http = ref.inject(HttpClient);
  return new ApiProvider(http);
});
```

O mesmo vale para qualquer serviço seu:

```typescript
export const accountProvider = webProvider('account', (ref) => {
  const accountService = ref.inject(AccountService);
  return new AccountProvider(accountService);
});
```

## Storage

Por padrão, o estado é salvo em `localStorage` com prefixo `web-provider`.

Usar `sessionStorage`:

```typescript
provideWebProviderInitializer({
  storage: 'sessionStorage',
  keyPrefix: 'admin',
});
```

Usar storage em memória:

```typescript
provideWebProviderInitializer({
  storage: 'memory',
});
```

Usar o storage diretamente:

```typescript
import { WebLocalStorage, webProvider, WebRef } from 'web-provider';

export const draftProvider = webProvider('draft', (ref: WebRef) => {
  const storage = ref.inject(WebLocalStorage);

  return {
    saveDraft: (value: string) => storage.setItem('draft', value),
    getDraft: () => storage.getItem<string>('draft', ''),
    clearDraft: () => storage.removeItem('draft'),
  };
});
```

Com `keyPrefix: 'admin'`, a chave `draft` é gravada como `admin:draft`.

## TTL por provider

```typescript
export const sessionProvider = webProvider(
  'session',
  () => new SessionProvider(),
  {
    ttl: 300_000,
    clearStorageOnExpire: true,
  }
);
```

## API pública

- `webProvider` — cria providers singleton por chave.
- `provideWebProviderInitializer` — registra injector Angular e opções globais.
- `WebNotifierProvider` — classe base com RxJS `Observable`.
- `WebNotifierSignalProvider` — classe base com Angular Signals.
- `WebRef` — helper para `inject`, storage e singletons internos.
- `WebLocalStorage` — serviço de storage com prefixo e backend configurável.
- `setGlobalOptions`, `WebProviderOptions`, `WebGlobalOptions` — configuração.

## Scripts

| Comando | Descrição |
|---------|-----------|
| `npm run build` | Compila TypeScript para `dist` |
| `npm test` | Executa testes |
| `npm run lint` | Verifica ESLint |
| `npm run test:package` | Compila, valida import ESM e simula pacote npm |

## Publicação

```bash
npm run lint
npm test
npm run test:package
npm publish
```

O pacote publica apenas a pasta `dist/`.

## Licença

MIT
